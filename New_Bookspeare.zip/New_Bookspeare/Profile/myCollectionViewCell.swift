//
//  myCollectionViewCell.swift
//  profile
//
//  Created by Jasmine Agrawal on 27/05/24.
//

import UIKit

class myCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var bookImage: UIView!
    
}
