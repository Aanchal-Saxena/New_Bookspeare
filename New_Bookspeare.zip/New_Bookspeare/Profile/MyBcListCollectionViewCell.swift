//
//  MyBcListCollectionViewCell.swift
//  profile
//
//  Created by Jasmine Agrawal on 27/05/24.
//

import UIKit

class MyBcListCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var bookImage1: UIImageView!
    
}
