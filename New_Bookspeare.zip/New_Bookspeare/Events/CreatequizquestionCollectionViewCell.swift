//
//  CreatequizquestionCollectionViewCell.swift
//  New_Bookspeare
//
//  Created by Sahil Raj on 06/06/24.
//

import UIKit

class CreatequizquestionCollectionViewCell: UICollectionViewCell {
    
}
